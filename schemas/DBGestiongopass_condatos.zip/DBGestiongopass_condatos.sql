-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.1.38-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para gestiongopass
CREATE DATABASE IF NOT EXISTS `gestiongopass` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `gestiongopass`;

-- Volcando estructura para tabla gestiongopass.barrio
CREATE TABLE IF NOT EXISTS `barrio` (
  `barrioId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `localidadId` int(11) NOT NULL,
  PRIMARY KEY (`barrioId`),
  KEY `localidadId` (`localidadId`),
  CONSTRAINT `barrio_ibfk_1` FOREIGN KEY (`localidadId`) REFERENCES `localidad` (`localidadId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.barrio: ~7 rows (aproximadamente)
DELETE FROM `barrio`;
/*!40000 ALTER TABLE `barrio` DISABLE KEYS */;
INSERT INTO `barrio` (`barrioId`, `nombre`, `estado`, `localidadId`) VALUES
	(1, 'BARRIO 1', 1, 1),
	(2, 'BARRIO 2', 1, 1),
	(3, 'BARRIO 3', 1, 1),
	(4, 'BARRIO 4', 1, 1),
	(5, 'BARRIO 5', 1, 1),
	(6, 'BARRIO 6', 1, 4),
	(7, 'BARRIO 7', 1, 4);
/*!40000 ALTER TABLE `barrio` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.campana
CREATE TABLE IF NOT EXISTS `campana` (
  `campanaId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`campanaId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.campana: ~2 rows (aproximadamente)
DELETE FROM `campana`;
/*!40000 ALTER TABLE `campana` DISABLE KEYS */;
INSERT INTO `campana` (`campanaId`, `nombre`, `fechaCreacion`, `estado`) VALUES
	(1, 'gestion', '2021-09-08 00:00:00', 1),
	(2, 'postventa', '2021-09-08 00:00:00', 1),
	(3, 'fidelizacion', '2021-09-08 00:00:00', 1);
/*!40000 ALTER TABLE `campana` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.campana_rol
CREATE TABLE IF NOT EXISTS `campana_rol` (
  `rolId` int(11) NOT NULL,
  `campanaId` int(11) NOT NULL,
  PRIMARY KEY (`campanaId`,`rolId`),
  KEY `rolId` (`rolId`),
  CONSTRAINT `campana_rol_ibfk_1` FOREIGN KEY (`rolId`) REFERENCES `rol` (`rolId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `campana_rol_ibfk_2` FOREIGN KEY (`campanaId`) REFERENCES `campana` (`campanaId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.campana_rol: ~7 rows (aproximadamente)
DELETE FROM `campana_rol`;
/*!40000 ALTER TABLE `campana_rol` DISABLE KEYS */;
INSERT INTO `campana_rol` (`rolId`, `campanaId`) VALUES
	(3, 1),
	(4, 1),
	(5, 1),
	(3, 2),
	(4, 2),
	(3, 3),
	(4, 3);
/*!40000 ALTER TABLE `campana_rol` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.campana_tipificacion
CREATE TABLE IF NOT EXISTS `campana_tipificacion` (
  `tipificacionId` int(11) NOT NULL,
  `campanaId` int(11) NOT NULL,
  PRIMARY KEY (`tipificacionId`,`campanaId`),
  KEY `campanaId` (`campanaId`),
  CONSTRAINT `campana_tipificacion_ibfk_1` FOREIGN KEY (`tipificacionId`) REFERENCES `tipificacion` (`tipificacionId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `campana_tipificacion_ibfk_2` FOREIGN KEY (`campanaId`) REFERENCES `campana` (`campanaId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.campana_tipificacion: ~11 rows (aproximadamente)
DELETE FROM `campana_tipificacion`;
/*!40000 ALTER TABLE `campana_tipificacion` DISABLE KEYS */;
INSERT INTO `campana_tipificacion` (`tipificacionId`, `campanaId`) VALUES
	(200, 2),
	(200, 3),
	(215, 1),
	(216, 1),
	(216, 2),
	(216, 3),
	(217, 1),
	(217, 2),
	(217, 3),
	(218, 1),
	(219, 1);
/*!40000 ALTER TABLE `campana_tipificacion` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.ciudad
CREATE TABLE IF NOT EXISTS `ciudad` (
  `ciudadId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `departamentoId` int(11) NOT NULL,
  PRIMARY KEY (`ciudadId`),
  KEY `departamentoId` (`departamentoId`),
  CONSTRAINT `ciudad_ibfk_1` FOREIGN KEY (`departamentoId`) REFERENCES `departamento` (`departamentoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.ciudad: ~0 rows (aproximadamente)
DELETE FROM `ciudad`;
/*!40000 ALTER TABLE `ciudad` DISABLE KEYS */;
INSERT INTO `ciudad` (`ciudadId`, `nombre`, `estado`, `departamentoId`) VALUES
	(1, 'BOGOTA', 1, 1),
	(2, 'CALI', 1, 2);
/*!40000 ALTER TABLE `ciudad` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.convenio
CREATE TABLE IF NOT EXISTS `convenio` (
  `convenioId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `usuarioId` int(11) NOT NULL,
  PRIMARY KEY (`convenioId`),
  KEY `usuarioId` (`usuarioId`),
  CONSTRAINT `convenio_ibfk_1` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`usuarioId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.convenio: ~4 rows (aproximadamente)
DELETE FROM `convenio`;
/*!40000 ALTER TABLE `convenio` DISABLE KEYS */;
INSERT INTO `convenio` (`convenioId`, `nombre`, `fechaCreacion`, `estado`, `ip`, `usuarioId`) VALUES
	(1, 'ITAU PRUEBA', '2021-09-08 00:00:00', 0, '::1', 1),
	(2, 'BANCOLOMBIA', '2021-09-08 00:00:00', 1, '::1', 1),
	(3, 'Prueba', '2021-08-18 13:31:54', 1, '::1', 1),
	(7, 'prueba 2', '2021-08-18 13:38:07', 1, '::1', 1),
	(8, 'prueba 2', '2021-08-18 13:38:14', 0, '::1', 1);
/*!40000 ALTER TABLE `convenio` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.departamento
CREATE TABLE IF NOT EXISTS `departamento` (
  `departamentoId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`departamentoId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.departamento: ~0 rows (aproximadamente)
DELETE FROM `departamento`;
/*!40000 ALTER TABLE `departamento` DISABLE KEYS */;
INSERT INTO `departamento` (`departamentoId`, `nombre`, `estado`) VALUES
	(1, 'BOGOTA', 1),
	(2, 'VALLE DEL CAUCA', 1);
/*!40000 ALTER TABLE `departamento` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.gestiongopass
CREATE TABLE IF NOT EXISTS `gestiongopass` (
  `gestionId` int(11) NOT NULL AUTO_INCREMENT,
  `placa` varchar(6) NOT NULL,
  `fechaGestion` datetime NOT NULL,
  `fechaReagendamiento` datetime DEFAULT NULL,
  `fechaVolverLlamar` datetime DEFAULT NULL,
  `fechaEntrega` datetime DEFAULT NULL,
  `observacion` varchar(45) DEFAULT NULL,
  `numTags` int(11) DEFAULT NULL,
  `ip` varchar(45) NOT NULL,
  `conoceMembresias` tinyint(1) DEFAULT NULL,
  `tipificacionId` int(11) DEFAULT NULL,
  `convenioId` int(11) DEFAULT NULL,
  `barrioId` int(11) DEFAULT NULL,
  `franjaHoraria` tinyint(1) DEFAULT NULL,
  `cedulaPersona` int(11) NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `presentacionPersonal` int(11) DEFAULT NULL,
  `direccionCasa` varchar(45) DEFAULT NULL,
  `direccionEntrega` varchar(45) DEFAULT NULL,
  `tipoBonoId` int(11) DEFAULT '1',
  `tipoMembresiaId` int(11) DEFAULT '1',
  `campanaId` int(11) NOT NULL,
  `calificacionPresentacionPersonal` int(11) DEFAULT NULL,
  `calificacionInfoClara` int(11) DEFAULT NULL,
  `calificacionAcompanamiento` int(11) DEFAULT NULL,
  `calificacionTiempoEspera` int(11) DEFAULT NULL,
  `calificacionComportamiento` int(11) DEFAULT NULL,
  `calificacionAmabilidad` int(11) DEFAULT NULL,
  `motivoNoContacto` varchar(45) DEFAULT NULL,
  `tagAsociado` int(11) NOT NULL,
  `fechaActivacion` date DEFAULT NULL,
  `redimeBono` tinyint(1) DEFAULT NULL,
  `fechaRedimeBono` date DEFAULT NULL,
  `adquiereMembresia` tinyint(1) DEFAULT NULL,
  `puntoActivacionId` int(11) DEFAULT NULL,
  `existeContacto` int(11) DEFAULT NULL,
  `infoBono` int(11) DEFAULT NULL,
  PRIMARY KEY (`gestionId`),
  UNIQUE KEY `placa_UNIQUE` (`placa`),
  KEY `tipificacionId` (`tipificacionId`),
  KEY `convenioId` (`convenioId`),
  KEY `barrioId` (`barrioId`),
  KEY `cedulaPersona` (`cedulaPersona`),
  KEY `usuarioId` (`usuarioId`),
  KEY `campanaId` (`campanaId`),
  KEY `tagAsociado` (`tagAsociado`),
  KEY `gestiongopass_ibfk_6` (`tipoBonoId`),
  KEY `gestiongopass_ibfk_7` (`tipoMembresiaId`),
  KEY `gestiongopass_ibfk_9` (`puntoActivacionId`),
  CONSTRAINT `gestiongopass_ibfk_1` FOREIGN KEY (`tipificacionId`) REFERENCES `tipificacion` (`tipificacionId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gestiongopass_ibfk_10` FOREIGN KEY (`tagAsociado`) REFERENCES `ventatag` (`tagAsociado`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gestiongopass_ibfk_2` FOREIGN KEY (`convenioId`) REFERENCES `convenio` (`convenioId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gestiongopass_ibfk_3` FOREIGN KEY (`barrioId`) REFERENCES `barrio` (`barrioId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gestiongopass_ibfk_4` FOREIGN KEY (`cedulaPersona`) REFERENCES `persona` (`cedulaPersona`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gestiongopass_ibfk_5` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`usuarioId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gestiongopass_ibfk_6` FOREIGN KEY (`tipoBonoId`) REFERENCES `tipobono` (`tipoBonoId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gestiongopass_ibfk_7` FOREIGN KEY (`tipoMembresiaId`) REFERENCES `tipomembresia` (`tipoMembresiaId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gestiongopass_ibfk_8` FOREIGN KEY (`campanaId`) REFERENCES `campana` (`campanaId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gestiongopass_ibfk_9` FOREIGN KEY (`puntoActivacionId`) REFERENCES `puntoactivacion` (`puntoActivacionId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.gestiongopass: ~51 rows (aproximadamente)
DELETE FROM `gestiongopass`;
/*!40000 ALTER TABLE `gestiongopass` DISABLE KEYS */;
INSERT INTO `gestiongopass` (`gestionId`, `placa`, `fechaGestion`, `fechaReagendamiento`, `fechaVolverLlamar`, `fechaEntrega`, `observacion`, `numTags`, `ip`, `conoceMembresias`, `tipificacionId`, `convenioId`, `barrioId`, `franjaHoraria`, `cedulaPersona`, `usuarioId`, `presentacionPersonal`, `direccionCasa`, `direccionEntrega`, `tipoBonoId`, `tipoMembresiaId`, `campanaId`, `calificacionPresentacionPersonal`, `calificacionInfoClara`, `calificacionAcompanamiento`, `calificacionTiempoEspera`, `calificacionComportamiento`, `calificacionAmabilidad`, `motivoNoContacto`, `tagAsociado`, `fechaActivacion`, `redimeBono`, `fechaRedimeBono`, `adquiereMembresia`, `puntoActivacionId`, `existeContacto`, `infoBono`) VALUES
	(1, 'AAE920', '2021-08-18 12:23:50', '2021-08-18 12:23:50', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 105 SAC', 1, '::1', 1, 215, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00', 0, '2021-08-04', 1, 1, 1, 1),
	(2, 'AAE901', '2021-08-12 10:28:19', NULL, '2021-09-12 00:00:00', '0000-00-00 00:00:00', 'No le interesa por el momento', 2, '::1', 1, 216, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04', 1, '2021-01-01', 0, 1, 1, 1),
	(3, 'AAE902', '2021-08-18 12:39:03', NULL, '2021-07-18 00:00:00', '0000-00-00 00:00:00', 'Purebas', 2, '::1', 1, 217, 1, 5, 1, 938202768, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 4, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-12', 0, '0000-00-00', 0, 2, 1, 1),
	(4, 'AAE921', '2021-08-12 16:28:28', NULL, NULL, '0000-00-00 00:00:00', '', 1, '::1', 1, 200, 2, 2, 0, 938727844, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 3, 5, 2, 3, 3, 2, 3, 5, 3, '', 0, '2021-08-18', 1, '2021-08-09', 1, 2, 1, 1),
	(5, 'asd999', '2021-08-12 16:19:50', NULL, NULL, '0000-00-00 00:00:00', '', 1, '::1', 0, 200, 1, 3, 0, 938350521, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 5, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04', 0, '0000-00-00', 1, 9, 1, 1),
	(6, 'XXX999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, NULL, NULL, NULL, 1, NULL, NULL),
	(7, 'ppp444', '2021-08-17 15:56:31', NULL, NULL, '2021-08-17 00:00:00', 'ppppp', 1, '::1', NULL, 215, 1, 2, 0, 936520547, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 6, 0, NULL),
	(8, 'MMM111', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 1, 1, 936565656, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 0, NULL),
	(9, 'pkn123', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'asasas', 1, '', NULL, 216, 2, 7, 1, 936752156, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 5, 0, NULL),
	(10, 'AAE922', '2021-08-17 13:23:17', '0000-00-00 00:00:00', NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '::1', NULL, 216, 1, 1, 0, 938300025, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, 0, NULL),
	(11, 'OOO111', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 6, 1, 938385567, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, 0, NULL),
	(12, 'LLL111', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 4, 0, 937809812, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 7, 0, NULL),
	(13, 'YYY123', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 5, 0, 936520741, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, 0, NULL),
	(14, 'RRR123', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 6, 0, 938202456, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 3, 0, NULL),
	(16, 'cba321', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'qwqwqw', 1, '', NULL, 216, 2, 1, 1, 936875544, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 8, 0, NULL),
	(17, 'aaa111', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 1, 0, 937785655, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, 0, NULL),
	(18, 'aaa222', '2021-08-17 15:55:48', NULL, NULL, '2021-08-17 00:00:00', 'Pruebas', 1, '::1', NULL, 215, 1, 2, 0, 938300385, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, 0, NULL),
	(19, 'aaa333', '2021-08-17 16:10:53', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '::1', NULL, 219, 1, 2, 0, 936520471, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 3, 0, NULL),
	(20, 'aaa444', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 2, 1, 936012445, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, 0, NULL),
	(21, 'aaa555', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 3, 0, 934500611, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 5, 0, NULL),
	(22, 'aaa666', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 3, 1, 937885544, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 6, 0, NULL),
	(23, 'aaa777', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 3, 0, 936512105, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 7, 0, NULL),
	(24, 'aaa888', '2021-08-17 15:39:27', NULL, NULL, '2021-08-17 00:00:00', 'Pruebas', 1, '::1', NULL, 216, 1, 4, 0, 938202200, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 8, 0, NULL),
	(25, 'aaa999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 4, 1, 939965585, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 9, 0, NULL),
	(26, 'asa123', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 1, 5, 0, 936541235, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 3, 0, NULL),
	(27, 'ZZZ999', '2021-08-17 12:40:45', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', NULL, NULL, 2, 3, 0, 938205580, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(28, 'PPP999', '2021-08-17 12:42:24', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', NULL, 215, 2, 3, 0, 938205580, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(29, 'TTT999', '2021-08-17 12:42:24', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', NULL, 215, 2, 3, 0, 938205580, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(34, 'rrr647', '2021-08-17 15:56:31', NULL, NULL, '2021-08-17 00:00:00', 'ppppp', 1, '::1', NULL, 215, 1, 2, 0, 936520547, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(35, 'bgy910', '2021-08-18 08:28:33', NULL, NULL, '2021-08-12 00:00:00', 'Segunda prueba', 1, '::1', NULL, 215, 1, 1, 0, 789456, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(36, 'tgv145', '2021-08-18 08:32:10', NULL, NULL, '2021-08-19 00:00:00', 'Tercera prueba', 1, '::1', NULL, 215, 1, 2, 0, 147852369, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(37, 'mmm369', '2021-08-18 08:32:10', NULL, NULL, '2021-08-19 00:00:00', 'Tercera prueba', 1, '::1', NULL, 215, 1, 2, 0, 147852369, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(38, 'oll986', '2021-08-18 08:34:10', NULL, NULL, '2021-08-19 00:00:00', 'cuarta prueba', 1, '::1', NULL, 215, 2, 5, 0, 963147528, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(39, 'bbb444', '2021-08-18 08:44:00', NULL, NULL, '2021-08-19 00:00:00', 'Quinta prueba', 1, '::1', NULL, 215, 1, 3, 0, 852147, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(40, 'www919', '2021-08-18 08:44:00', NULL, NULL, '2021-08-19 00:00:00', 'Quinta prueba', 1, '::1', NULL, 215, 1, 3, 0, 852147, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(41, 'njp009', '2021-08-18 08:46:32', NULL, NULL, '2021-08-19 00:00:00', 'prueba 6', 1, '::1', NULL, 215, 1, 1, 0, 987654, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(42, 'qrp090', '2021-08-18 08:46:32', NULL, NULL, '2021-08-19 00:00:00', 'prueba 6', 1, '::1', NULL, 215, 1, 1, 0, 987654, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(43, 'aza999', '2021-08-18 08:48:54', NULL, NULL, '2021-08-19 00:00:00', 'prueba 7 ', 1, '::1', NULL, 215, 2, 2, 0, 4654981, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(44, 'pzq943', '2021-08-18 08:51:04', NULL, NULL, '2021-08-19 00:00:00', 'prueba 8 ', 1, '::1', NULL, 215, 1, 1, 0, 1213243534, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(45, 'lal645', '2021-08-18 08:53:14', NULL, NULL, '2021-08-20 00:00:00', 'prueba 9', 1, '::1', NULL, 215, 1, 2, 0, 1212, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(46, 'xxz990', '2021-08-18 08:55:15', NULL, NULL, '2021-08-19 00:00:00', 'prueba 10 ', 1, '::1', NULL, 215, 1, 2, 0, 654654, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(47, 'qpo110', '2021-08-18 08:55:15', NULL, NULL, '2021-08-19 00:00:00', 'prueba 10 ', 1, '::1', NULL, 215, 1, 2, 0, 654654, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(52, 'QWM456', '2021-08-19 09:55:08', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(53, 'YHJ999', '2021-08-19 09:57:27', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(54, 'BBB836', '2021-08-19 09:57:27', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(55, 'ZXC789', '2021-08-19 09:57:27', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(56, 'LPJ901', '2021-08-19 10:20:49', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(57, 'QWE851', '2021-08-19 11:22:58', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 56465, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(58, 'ZGT963', '2021-08-19 11:22:58', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 34657, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(59, 'MPZ109', '2021-08-19 11:22:58', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 3434, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	(60, 'PPZ937', '2021-08-19 11:22:58', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 52464321, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `gestiongopass` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.historico_convenio
CREATE TABLE IF NOT EXISTS `historico_convenio` (
  `historicoConvenioId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `fechaInsert` datetime DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  `convenioId` int(11) NOT NULL,
  `fechaUpdate` datetime DEFAULT NULL,
  `usuarioId` int(11) NOT NULL,
  `fechaDelete` datetime DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`historicoConvenioId`),
  KEY `convenioId` (`convenioId`),
  KEY `usuarioId` (`usuarioId`),
  CONSTRAINT `historico_convenio_ibfk_1` FOREIGN KEY (`convenioId`) REFERENCES `convenio` (`convenioId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `historico_convenio_ibfk_2` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`usuarioId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.historico_convenio: ~13 rows (aproximadamente)
DELETE FROM `historico_convenio`;
/*!40000 ALTER TABLE `historico_convenio` DISABLE KEYS */;
INSERT INTO `historico_convenio` (`historicoConvenioId`, `nombre`, `fechaInsert`, `estado`, `convenioId`, `fechaUpdate`, `usuarioId`, `fechaDelete`, `ip`) VALUES
	(1, 'ITAU PRUEBA', NULL, 1, 1, '2021-08-18 13:12:36', 1, NULL, '::1'),
	(2, 'ITAU PRUEBAs', NULL, 1, 1, '2021-08-18 13:13:12', 1, NULL, '::1'),
	(3, 'BANCOLOMBIA', NULL, 0, 2, '2021-08-18 13:16:54', 1, NULL, '::1'),
	(4, 'BANCOLOMBIA', NULL, 0, 2, '2021-08-18 13:18:10', 1, NULL, '::1'),
	(5, 'BANCOLOMBIA', NULL, 0, 2, '2021-08-18 13:19:27', 1, NULL, '::1'),
	(6, 'BANCOLOMBIA', NULL, 0, 2, '2021-08-18 13:23:44', 1, NULL, '::1'),
	(7, 'BANCOLOMBIA', NULL, 1, 2, '2021-08-18 13:24:04', 1, NULL, '::1'),
	(8, 'ITAU PRUEBA', NULL, 1, 1, '2021-08-18 13:24:18', 1, NULL, '::1'),
	(9, 'ITAU PRUEBA', NULL, 0, 1, '2021-08-18 13:24:30', 1, NULL, '::1'),
	(10, 'Prueba', '2021-08-18 13:31:54', 1, 3, '0000-00-00 00:00:00', 1, NULL, '::1'),
	(11, 'prueba 2', '2021-08-18 13:38:07', 1, 7, NULL, 1, NULL, '::1'),
	(12, 'prueba 2', '2021-08-18 13:38:14', 1, 8, NULL, 1, NULL, '::1'),
	(13, 'prueba 2', NULL, 0, 8, '2021-08-18 13:38:26', 1, NULL, '::1'),
	(14, 'prueba 2', NULL, 0, 8, '2021-08-18 13:40:44', 1, NULL, '::1'),
	(15, 'prueba 2', NULL, 0, 8, '2021-08-18 13:53:29', 1, NULL, '::1');
/*!40000 ALTER TABLE `historico_convenio` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.historico_gestiongopass
CREATE TABLE IF NOT EXISTS `historico_gestiongopass` (
  `historicoGestionGopassId` int(11) NOT NULL AUTO_INCREMENT,
  `placa` varchar(6) NOT NULL,
  `fechaGestion` datetime NOT NULL,
  `fechaReagendamiento` datetime DEFAULT NULL,
  `fechaVolverLlamar` datetime DEFAULT NULL,
  `fechaEntrega` datetime DEFAULT NULL,
  `observacion` varchar(45) DEFAULT NULL,
  `numTags` int(11) DEFAULT NULL,
  `ip` varchar(45) NOT NULL,
  `conoceMembresias` tinyint(1) DEFAULT NULL,
  `tipificacionId` int(11) DEFAULT NULL,
  `convenioId` int(11) DEFAULT NULL,
  `barrioId` int(11) DEFAULT NULL,
  `franjaHoraria` tinyint(1) DEFAULT NULL,
  `cedulaPersona` int(11) NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `presentacionPersonal` int(11) DEFAULT NULL,
  `direccionCasa` varchar(45) DEFAULT NULL,
  `direccionEntrega` varchar(45) DEFAULT NULL,
  `tipoBonoId` int(11) DEFAULT NULL,
  `tipoMembresiaId` int(11) DEFAULT NULL,
  `campanaId` int(11) NOT NULL,
  `calificacionPresentacionPersonal` int(11) DEFAULT NULL,
  `calificacionInfoClara` int(11) DEFAULT NULL,
  `calificacionAcompanamiento` int(11) DEFAULT NULL,
  `calificacionTiempoEspera` int(11) DEFAULT NULL,
  `calificacionComportamiento` int(11) DEFAULT NULL,
  `calificacionAmabilidad` int(11) DEFAULT NULL,
  `motivoNoContacto` varchar(45) DEFAULT NULL,
  `tagAsociado` int(11) NOT NULL,
  `fechaActivacion` datetime DEFAULT NULL,
  `redimeBono` tinyint(1) DEFAULT NULL,
  `fechaRedimeBono` datetime DEFAULT NULL,
  `adquiereMembresia` tinyint(1) DEFAULT NULL,
  `puntoActivacionId` int(11) DEFAULT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `fechaUpdate` datetime DEFAULT NULL,
  `fechaDelete` datetime DEFAULT NULL,
  `gestionId` int(11) NOT NULL,
  `existeContacto` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`historicoGestionGopassId`),
  KEY `gestionId` (`gestionId`),
  KEY `usuarioId` (`usuarioId`),
  CONSTRAINT `historico_gestiongopass_ibfk_1` FOREIGN KEY (`gestionId`) REFERENCES `gestiongopass` (`gestionId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `historico_gestiongopass_ibfk_2` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`usuarioId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=202 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.historico_gestiongopass: ~193 rows (aproximadamente)
DELETE FROM `historico_gestiongopass`;
/*!40000 ALTER TABLE `historico_gestiongopass` DISABLE KEYS */;
INSERT INTO `historico_gestiongopass` (`historicoGestionGopassId`, `placa`, `fechaGestion`, `fechaReagendamiento`, `fechaVolverLlamar`, `fechaEntrega`, `observacion`, `numTags`, `ip`, `conoceMembresias`, `tipificacionId`, `convenioId`, `barrioId`, `franjaHoraria`, `cedulaPersona`, `usuarioId`, `presentacionPersonal`, `direccionCasa`, `direccionEntrega`, `tipoBonoId`, `tipoMembresiaId`, `campanaId`, `calificacionPresentacionPersonal`, `calificacionInfoClara`, `calificacionAcompanamiento`, `calificacionTiempoEspera`, `calificacionComportamiento`, `calificacionAmabilidad`, `motivoNoContacto`, `tagAsociado`, `fechaActivacion`, `redimeBono`, `fechaRedimeBono`, `adquiereMembresia`, `puntoActivacionId`, `fechaCreacion`, `fechaUpdate`, `fechaDelete`, `gestionId`, `existeContacto`) VALUES
	(1, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '::1', NULL, 216, 1, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-10 13:40:16', NULL, 1, 0),
	(2, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '::1', NULL, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-10 13:40:32', NULL, 1, 0),
	(3, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '::1', NULL, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-10 13:40:38', NULL, 1, 0),
	(4, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '::1', NULL, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-10 13:40:45', NULL, 1, 0),
	(5, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '::1', NULL, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-10 13:40:51', NULL, 1, 0),
	(6, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '::1', NULL, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0000-00-00 00:00:00', NULL, NULL, NULL, 1, NULL, '2021-08-10 13:40:57', NULL, 1, 0),
	(7, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '::1', NULL, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '0000-00-00 00:00:00', NULL, NULL, NULL, 1, NULL, '2021-08-10 13:41:03', NULL, 1, 0),
	(8, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '::1', NULL, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, 'asas', 0, '0000-00-00 00:00:00', NULL, NULL, NULL, 1, NULL, '2021-08-10 13:41:09', NULL, 1, 0),
	(9, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 13:49:23', NULL, 1, 0),
	(10, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 13:58:18', NULL, 1, 0),
	(11, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:11:29', NULL, 1, 0),
	(12, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:23:54', NULL, 1, 0),
	(13, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:24:49', NULL, 1, 0),
	(14, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:24:59', NULL, 1, 0),
	(15, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:25:06', NULL, 1, 0),
	(16, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:25:12', NULL, 1, 0),
	(17, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:25:18', NULL, 1, 0),
	(18, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:25:25', NULL, 1, 1),
	(19, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:26:11', NULL, 1, 1),
	(20, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 3, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:26:20', NULL, 1, 1),
	(21, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 3, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 15:29:33', NULL, 1, 1),
	(22, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 200, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 3, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 1, 1, NULL, '2021-08-10 15:37:02', NULL, 1, 1),
	(23, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 200, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 3, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 1, 1, NULL, '2021-08-10 15:37:32', NULL, 1, 1),
	(24, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 215, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 3, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 1, 1, NULL, '2021-08-10 15:47:59', NULL, 1, 1),
	(25, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 3, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 1, 1, NULL, '2021-08-10 15:48:29', NULL, 1, 1),
	(26, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 1, 1, NULL, '2021-08-10 15:53:18', NULL, 1, 1),
	(27, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 200, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 5, 5, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-10 15:55:05', NULL, 1, 1),
	(28, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 200, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 5, 5, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-10 15:55:06', NULL, 1, 1),
	(29, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 200, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-10 15:57:07', NULL, 1, 1),
	(30, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-10 15:58:06', NULL, 1, 1),
	(31, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-10 16:01:17', NULL, 1, 1),
	(32, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, '', 0, '0000-00-00 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-10 16:01:23', NULL, 1, 1),
	(33, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '2021-08-11 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 16:06:51', NULL, 1, 0),
	(34, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '2021-08-11 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 16:06:51', NULL, 1, 0),
	(35, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 16:27:18', NULL, 1, 0),
	(36, 'AAE920', '2021-08-10 16:29:49', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 16:29:49', NULL, 1, 0),
	(37, 'AAE920', '2021-08-10 16:29:49', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 16:29:49', NULL, 1, 0),
	(38, 'AAE920', '2021-08-10 16:29:49', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 1, 2, 0, 0, 0, 0, 0, 0, 'asas', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 16:32:14', NULL, 1, 0),
	(39, 'AAE920', '2021-08-10 16:35:38', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 1, 2, 0, 0, 0, 0, 0, 0, 'asasas', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 16:35:38', NULL, 1, 0),
	(40, 'AAE920', '2021-08-10 16:35:38', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 1, 2, 0, 0, 0, 0, 0, 0, 'asasas', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 16:35:38', NULL, 1, 0),
	(41, 'AAE920', '2021-08-10 16:53:46', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 200, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 2, 2, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 1, 1, NULL, '2021-08-10 16:53:46', NULL, 1, 1),
	(42, 'AAE920', '2021-08-10 16:53:46', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 2, 2, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 1, 1, NULL, '2021-08-10 16:55:41', NULL, 1, 1),
	(43, 'AAE920', '2021-08-10 16:58:25', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 2, 2, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 1, 1, NULL, '2021-08-10 16:58:26', NULL, 1, 1),
	(44, 'AAE920', '2021-08-10 16:59:50', NULL, '2021-09-10 00:00:00', '0000-00-00 00:00:00', 'asas', 2, '::1', 0, 217, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 16:59:50', NULL, 1, 1),
	(45, 'AAE920', '2021-08-10 17:00:15', NULL, '2021-09-10 00:00:00', '0000-00-00 00:00:00', 'asas', 2, '::1', 0, 217, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 17:00:15', NULL, 1, 1),
	(46, 'AAE920', '2021-08-10 17:00:15', NULL, '2021-09-10 00:00:00', '0000-00-00 00:00:00', 'asas', 2, '::1', 0, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 2, 2, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-07 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-10 17:01:15', NULL, 1, 1),
	(47, 'AAE920', '2021-08-10 17:16:54', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 200, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 2, 2, 3, 2, 1, 3, 2, 2, '', 0, '2021-08-07 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-10 17:16:54', NULL, 1, 1),
	(48, 'AAE901', '0000-00-00 00:00:00', NULL, '2021-07-10 00:00:00', '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 217, 1, 4, 0, 936545115, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-10 17:30:18', NULL, 2, 0),
	(49, 'AAE901', '0000-00-00 00:00:00', NULL, '2021-07-15 00:00:00', '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 217, 1, 4, 0, 936545115, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-10 17:30:53', NULL, 2, 0),
	(50, 'AAE901', '0000-00-00 00:00:00', NULL, '2021-08-15 00:00:00', '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 217, 1, 4, 0, 936545115, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-10 17:31:38', NULL, 2, 0),
	(51, 'AAE901', '0000-00-00 00:00:00', NULL, '2021-08-10 00:00:00', '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 217, 1, 4, 0, 936545115, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-10 17:31:53', NULL, 2, 0),
	(52, 'AAE901', '0000-00-00 00:00:00', NULL, '2021-08-10 00:00:00', '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 217, 1, 4, 0, 936545115, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 1, '2021-04-04 00:00:00', NULL, 1, NULL, '2021-08-11 08:48:13', NULL, 2, 0),
	(53, 'AAE901', '0000-00-00 00:00:00', NULL, '2021-08-10 00:00:00', '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 217, 1, 4, 0, 936545115, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 1, '2021-04-04 00:00:00', NULL, 1, NULL, '2021-08-11 08:59:36', NULL, 2, 0),
	(54, 'AAE901', '2021-08-11 09:25:23', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', NULL, 200, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 3, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-05 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-11 09:25:23', NULL, 2, 1),
	(55, 'AAE901', '2021-08-11 09:27:40', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', NULL, 200, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 3, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-05 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-11 09:27:40', NULL, 2, 1),
	(56, 'AAE901', '2021-08-11 09:28:10', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', NULL, 200, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 3, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-05 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-11 09:28:10', NULL, 2, 1),
	(57, 'AAE901', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', NULL, 200, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 3, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-05 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-11 09:28:36', NULL, 2, 1),
	(58, 'XXX999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-11 12:04:08', NULL, 6, 0),
	(59, 'asd999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 9, NULL, '2021-08-11 12:04:08', NULL, 5, 0),
	(60, 'AAE921', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', NULL, 216, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:04:08', NULL, 4, 0),
	(61, 'AAE902', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:04:08', NULL, 3, 0),
	(62, 'AAE902', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:05:23', NULL, 3, 0),
	(63, 'AAE921', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', NULL, 216, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:05:23', NULL, 4, 0),
	(64, 'asd999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 9, NULL, '2021-08-11 12:05:23', NULL, 5, 0),
	(65, 'XXX999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-11 12:05:23', NULL, 6, 0),
	(66, 'AAE902', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:07:12', NULL, 3, 0),
	(67, 'AAE921', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', NULL, 216, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:07:12', NULL, 4, 0),
	(68, 'asd999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 9, NULL, '2021-08-11 12:07:12', NULL, 5, 0),
	(69, 'XXX999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-11 12:07:12', NULL, 6, 0),
	(70, 'AAE902', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:09:08', NULL, 3, 0),
	(71, 'AAE902', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:34:43', NULL, 3, 0),
	(72, 'AAE921', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', NULL, 216, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:34:43', NULL, 4, 0),
	(73, 'AAE902', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:35:59', NULL, 3, NULL),
	(77, 'AAE921', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', NULL, 216, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:37:12', NULL, 4, NULL),
	(78, 'asd999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 9, NULL, '2021-08-11 12:37:12', NULL, 5, NULL),
	(79, 'XXX999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-11 12:37:12', NULL, 6, NULL),
	(80, 'AAE902', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 12:37:18', NULL, 3, 0),
	(81, 'AAE902', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', 1, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 15:09:16', NULL, 3, 0),
	(82, 'AAE901', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 200, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 3, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-05 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-11 15:10:10', NULL, 2, 1),
	(83, 'AAE921', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', 0, 216, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-11 15:10:10', NULL, 4, NULL),
	(84, 'AAE921', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', 0, 200, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 2, NULL, '2021-08-11 15:12:35', NULL, 4, 1),
	(85, 'AAE902', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', 1, 200, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, '0000-00-00 00:00:00', 0, 2, NULL, '2021-08-11 15:12:35', NULL, 3, 0),
	(86, 'AAE901', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 200, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 3, 2, 2, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-05 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-11 15:12:35', NULL, 2, 1),
	(87, 'AAE921', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', 0, 200, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 2, NULL, '2021-08-11 15:17:06', NULL, 4, 1),
	(88, 'AAE921', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', 0, 200, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, 1, 2, NULL, '2021-08-11 15:47:21', NULL, 4, 1),
	(89, 'asd999', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 9, NULL, '2021-08-11 16:10:13', NULL, 5, NULL),
	(90, 'XXX999', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 1, 1, NULL, '2021-08-11 16:10:13', NULL, 6, NULL),
	(91, 'AAE902', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', 1, 200, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, '0000-00-00 00:00:00', 0, 2, NULL, '2021-08-11 16:10:54', NULL, 3, 1),
	(92, 'asd999', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0, 9, NULL, '2021-08-11 16:10:54', NULL, 5, 1),
	(93, 'XXX999', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 1, 1, NULL, '2021-08-11 16:10:54', NULL, 6, 1),
	(94, 'AAE901', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 200, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 3, 2, 2, 3, 5, 5, 2, 2, 5, '', 0, '2021-08-05 00:00:00', 1, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-11 16:38:50', NULL, 2, 1),
	(95, 'AAE902', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', 1, 200, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 4, 1, 2, 5, 2, 5, NULL, 0, NULL, 0, '0000-00-00 00:00:00', 0, 2, NULL, '2021-08-11 16:38:50', NULL, 3, 1),
	(96, 'AAE921', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', 0, 200, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 5, 4, 2, 5, 2, 5, NULL, 0, NULL, 0, NULL, 1, 2, NULL, '2021-08-11 16:38:50', NULL, 4, 1),
	(97, 'asd999', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 2, 3, 2, 5, 3, 4, NULL, 0, NULL, NULL, NULL, 0, 9, NULL, '2021-08-11 16:38:50', NULL, 5, 1),
	(98, 'XXX999', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 3, 4, 3, 2, 3, 3, NULL, 0, NULL, NULL, NULL, 1, 1, NULL, '2021-08-11 16:38:50', NULL, 6, 1),
	(99, 'asd999', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 2, 3, 2, 5, 3, 4, NULL, 0, NULL, NULL, NULL, 0, 9, NULL, '2021-08-12 08:28:25', NULL, 5, 0),
	(100, 'XXX999', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 3, 4, 3, 2, 3, 3, NULL, 0, NULL, NULL, NULL, 1, 1, NULL, '2021-08-12 08:28:26', NULL, 6, 0),
	(101, 'XXX999', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 3, 4, 3, 2, 3, 3, NULL, 0, NULL, NULL, NULL, 0, 1, NULL, '2021-08-12 08:35:28', NULL, 6, 0),
	(102, 'AAE902', '2021-08-11 09:28:36', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', 1, 219, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 4, 1, 2, 5, 2, 5, NULL, 0, NULL, 0, '0000-00-00 00:00:00', 0, 2, NULL, '2021-08-12 08:37:58', NULL, 3, 1),
	(103, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-12 10:01:11', NULL, 1, 1),
	(104, 'AAE901', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 216, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-12 10:01:11', NULL, 2, 0),
	(105, 'AAE902', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', 1, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, 0, '0000-00-00 00:00:00', 0, 2, NULL, '2021-08-12 10:01:11', NULL, 3, 0),
	(106, 'AAE921', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', 0, 216, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, 0, NULL, 0, 2, NULL, '2021-08-12 10:01:11', NULL, 4, 0),
	(107, 'asd999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, 0, NULL, 0, 9, NULL, '2021-08-12 10:01:12', NULL, 5, 0),
	(108, 'XXX999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, 0, NULL, 0, 1, NULL, '2021-08-12 10:01:12', NULL, 6, 0),
	(109, 'AAE901', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 216, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', NULL, '0000-00-00 00:00:00', NULL, 1, NULL, '2021-08-12 10:01:46', NULL, 2, NULL),
	(110, 'AAE902', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', 1, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, NULL, '0000-00-00 00:00:00', NULL, 2, NULL, '2021-08-12 10:01:46', NULL, 3, NULL),
	(111, 'AAE921', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', 0, 216, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-12 10:01:46', NULL, 4, NULL),
	(112, 'asd999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'asas', 1, '', NULL, 216, 1, 3, 0, 938350521, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, NULL, NULL, NULL, 9, NULL, '2021-08-12 10:01:46', NULL, 5, NULL),
	(113, 'XXX999', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 216, 2, 7, 1, 938755645, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, NULL, NULL, NULL, 1, NULL, '2021-08-12 10:01:46', NULL, 6, NULL),
	(114, 'AAE901', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', NULL, 216, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', NULL, '0000-00-00 00:00:00', NULL, 1, NULL, '2021-08-12 10:02:21', NULL, 2, NULL),
	(115, 'AAE902', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 2, '', NULL, 216, 1, 5, 1, 938202768, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, NULL, '0000-00-00 00:00:00', NULL, 2, NULL, '2021-08-12 10:02:21', NULL, 3, NULL),
	(116, 'AAE921', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'pruebas', 1, '', NULL, 216, 2, 2, 0, 938727844, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 2, 0, 0, 0, 0, 0, 0, 'NULL', 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-12 10:02:21', NULL, 4, NULL),
	(117, 'AAE901', '2021-08-12 10:28:19', NULL, '2021-09-12 00:00:00', '0000-00-00 00:00:00', 'No le interesa por el momento', 2, '::1', 1, 217, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-12 10:28:19', NULL, 2, 1),
	(118, 'AAE901', '2021-08-12 10:28:19', NULL, '2021-07-12 00:00:00', '0000-00-00 00:00:00', 'No le interesa por el momento', 2, '::1', 1, 217, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04 00:00:00', 0, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-12 10:30:06', NULL, 2, 1),
	(119, 'AAE901', '2021-08-12 10:28:19', NULL, '2021-07-12 00:00:00', '0000-00-00 00:00:00', 'No le interesa por el momento', 2, '::1', 1, 217, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04 00:00:00', 1, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-12 10:33:04', NULL, 2, 1),
	(120, 'AAE901', '2021-08-12 10:28:19', NULL, '2021-07-12 00:00:00', '0000-00-00 00:00:00', 'No le interesa por el momento', 2, '::1', 1, 217, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04 00:00:00', 1, '2021-01-01 00:00:00', 0, 1, NULL, '2021-08-12 10:33:29', NULL, 2, 1),
	(121, 'AAE901', '2021-08-12 10:28:19', NULL, '2021-07-12 00:00:00', '0000-00-00 00:00:00', 'No le interesa por el momento', 2, '::1', 1, 217, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04 00:00:00', 1, '0000-00-00 00:00:00', 0, 1, NULL, '2021-08-12 10:34:06', NULL, 2, 1),
	(122, 'AAE901', '2021-08-12 10:28:19', NULL, '2021-07-12 00:00:00', '0000-00-00 00:00:00', 'No le interesa por el momento', 2, '::1', 1, 217, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04 00:00:00', 1, '2021-01-01 00:00:00', 0, 1, NULL, '2021-08-12 10:49:56', NULL, 2, 1),
	(123, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', '', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-12 12:38:58', NULL, 1, 1),
	(124, 'AAE920', '0000-00-00 00:00:00', NULL, NULL, '0000-00-00 00:00:00', 'Esta es una observación de prueba', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-12 13:25:55', NULL, 1, 1),
	(125, 'AAE920', '2021-08-12 00:00:00', '2021-08-12 00:00:00', NULL, '2021-08-12 00:00:00', 'Esta es una observación de prueba', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-12 16:09:08', NULL, 1, 1),
	(126, 'AAE920', '2021-08-12 00:00:00', '2021-08-12 00:00:00', NULL, '2021-08-12 00:00:00', 'Esta es una observación de prueba', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-12 16:09:30', NULL, 1, 1),
	(127, 'AAE920', '2021-08-12 00:00:00', '2021-08-12 00:00:00', NULL, '2021-08-12 00:00:00', 'Esta es una observación de prueba 2', 2, '::1', 1, 216, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-12 16:10:10', NULL, 1, 1),
	(128, 'asd999', '2021-08-12 16:16:45', NULL, '2021-09-12 00:00:00', '0000-00-00 00:00:00', 'asas', 1, '::1', 0, 217, 1, 3, 0, 938350521, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 5, 3, 3, 2, 4, 1, 3, 4, '', 0, '2021-08-04 00:00:00', 0, '0000-00-00 00:00:00', 0, 9, NULL, '2021-08-12 16:16:45', NULL, 5, 1),
	(129, 'asd999', '2021-08-12 16:16:45', NULL, '2021-07-12 00:00:00', '0000-00-00 00:00:00', 'asas', 1, '::1', 0, 217, 1, 3, 0, 938350521, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 5, 3, 3, 2, 4, 1, 3, 4, '', 0, '2021-08-04 00:00:00', 0, '0000-00-00 00:00:00', 0, 9, NULL, '2021-08-12 16:18:20', NULL, 5, 1),
	(130, 'asd999', '2021-08-12 16:19:50', NULL, NULL, '0000-00-00 00:00:00', '', 1, '::1', 0, 200, 1, 3, 0, 938350521, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 2, 5, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04 00:00:00', 0, '0000-00-00 00:00:00', 1, 9, NULL, '2021-08-12 16:19:50', NULL, 5, 1),
	(131, 'AAE921', '2021-08-12 16:28:28', NULL, NULL, '0000-00-00 00:00:00', '', 1, '::1', 1, 200, 2, 2, 0, 938727844, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 3, 5, 2, 3, 3, 2, 3, 5, 3, '', 0, '2021-08-18 00:00:00', 1, '2021-08-09 00:00:00', 1, 2, NULL, '2021-08-12 16:28:28', NULL, 4, 1),
	(132, 'AAE901', '2021-08-12 10:28:19', NULL, '2021-07-12 00:00:00', '0000-00-00 00:00:00', 'No le interesa por el momento', 2, '::1', 1, 216, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04 00:00:00', 1, '2021-01-01 00:00:00', 0, 1, NULL, '2021-08-12 17:37:08', NULL, 2, 1),
	(133, 'AAE901', '2021-08-12 10:28:19', NULL, '2021-09-12 00:00:00', '0000-00-00 00:00:00', 'No le interesa por el momento', 2, '::1', 1, 216, 1, 4, 0, 936545115, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-04 00:00:00', 1, '2021-01-01 00:00:00', 0, 1, NULL, '2021-08-12 17:49:59', NULL, 2, 1),
	(134, 'AAE920', '2021-08-17 00:00:00', '2021-08-17 00:00:00', NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 3', 2, '::1', 1, 216, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 09:14:59', NULL, 1, 1),
	(135, 'AAE920', '2021-08-17 00:00:00', '2021-08-17 00:00:00', NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 3', 2, '::1', 1, 215, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 10:35:36', NULL, 1, 1),
	(136, 'AAE920', '2021-08-17 00:00:00', '2021-08-17 00:00:00', NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 3', 2, '::1', 1, 215, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:14:10', NULL, 1, 1),
	(137, 'AAE920', '2021-08-17 00:00:00', '2021-08-17 00:00:00', NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 3', 2, '::1', 1, 215, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:15:35', NULL, 1, 1),
	(138, 'AAE920', '2021-08-17 00:00:00', '2021-08-17 00:00:00', NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 3', 2, '::1', 1, 215, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:15:44', NULL, 1, 1),
	(139, 'AAE920', '2021-08-17 00:00:00', '2021-08-17 00:00:00', NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 3', 2, '::1', 1, 215, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:15:53', NULL, 1, 1),
	(140, 'AAE920', '2021-08-17 00:00:00', '2021-08-17 00:00:00', NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 3', 2, '::1', 1, 215, 1, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:16:00', NULL, 1, 1),
	(141, 'AAE920', '2021-08-17 00:00:00', '2021-08-17 00:00:00', NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 2, '::1', 1, 215, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:16:10', NULL, 1, 1),
	(142, 'AAE920', '2021-08-17 00:00:00', '2021-08-17 00:00:00', NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 2, '::1', 1, 215, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:16:33', NULL, 1, 1),
	(143, 'AAE920', '2021-08-17 00:00:00', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:16:53', NULL, 1, 1),
	(144, 'AAE920', '2021-08-17 12:18:24', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:18:24', NULL, 1, 1),
	(145, 'AAE920', '2021-08-17 12:21:00', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:21:00', NULL, 1, 1),
	(146, 'AAE920', '2021-08-17 12:22:29', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:22:29', NULL, 1, 1),
	(147, 'AAE920', '2021-08-17 12:22:57', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:22:57', NULL, 1, 1),
	(148, 'AAE920', '2021-08-17 12:24:03', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 2, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:24:03', NULL, 1, 1),
	(149, 'ZZZ999', '2021-08-17 12:38:21', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', NULL, NULL, 2, 3, 0, 938205580, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-17 12:38:22', NULL, NULL, 27, NULL),
	(150, 'ZZZ999', '2021-08-17 12:40:45', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', NULL, NULL, 2, 3, 0, 938205580, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2021-08-17 12:40:45', NULL, 27, NULL),
	(151, 'AAE920', '2021-08-17 12:40:45', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:40:45', NULL, 1, 1),
	(152, 'AAE920', '2021-08-17 12:41:44', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:41:44', NULL, 1, 1),
	(153, 'PPP999', '2021-08-17 12:41:44', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', NULL, NULL, 2, 3, 0, 938205580, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-17 12:41:44', NULL, NULL, 28, NULL),
	(154, 'TTT999', '2021-08-17 12:41:44', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', NULL, NULL, 2, 3, 0, 938205580, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-17 12:41:44', NULL, NULL, 29, NULL),
	(155, 'AAE920', '2021-08-17 12:42:24', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 12:42:24', NULL, 1, 1),
	(156, 'PPP999', '2021-08-17 12:42:24', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', NULL, 215, 2, 3, 0, 938205580, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2021-08-17 12:42:24', NULL, 28, NULL),
	(157, 'TTT999', '2021-08-17 12:42:24', NULL, NULL, '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', NULL, 215, 2, 3, 0, 938205580, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2021-08-17 12:42:24', NULL, 29, NULL),
	(158, 'AAE922', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '', NULL, 215, 1, 1, 0, 938300025, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, NULL, '2021-08-17 13:02:37', NULL, 10, 0),
	(159, 'AAE920', '2021-08-17 13:18:55', NULL, '2021-08-19 00:00:00', '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 215, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 13:18:55', NULL, 1, 1),
	(160, 'AAE920', '2021-08-17 13:21:53', NULL, '2021-08-19 00:00:00', '2021-08-17 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 217, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-17 13:21:53', NULL, 1, 1),
	(161, 'AAE922', '2021-08-17 13:23:17', '0000-00-00 00:00:00', NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '::1', NULL, 216, 1, 1, 0, 938300025, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 4, NULL, '2021-08-17 13:23:17', NULL, 10, 0),
	(162, 'aaa888', '2021-08-17 15:38:52', NULL, NULL, '2021-08-17 00:00:00', 'Pruebas', 1, '::1', NULL, 216, 1, 4, 0, 938202200, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 8, NULL, '2021-08-17 15:38:52', NULL, 24, 0),
	(163, 'aaa888', '2021-08-17 15:39:27', NULL, NULL, '2021-08-17 00:00:00', 'Pruebas', 1, '::1', NULL, 216, 1, 4, 0, 938202200, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 8, NULL, '2021-08-17 15:39:27', NULL, 24, 0),
	(164, 'aaa222', '2021-08-17 15:55:38', NULL, NULL, '2021-08-17 00:00:00', 'Pruebas', 1, '::1', NULL, 215, 1, 2, 0, 938300385, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-17 15:55:38', NULL, 18, 0),
	(165, 'aaa222', '2021-08-17 15:55:48', NULL, NULL, '2021-08-17 00:00:00', 'Pruebas', 1, '::1', NULL, 215, 1, 2, 0, 938300385, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 2, NULL, '2021-08-17 15:55:48', NULL, 18, 0),
	(166, 'ppp444', '2021-08-17 15:56:31', NULL, NULL, '2021-08-17 00:00:00', 'ppppp', 1, '::1', NULL, 215, 1, 2, 0, 936520547, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 6, NULL, '2021-08-17 15:56:31', NULL, 7, 0),
	(167, 'rrr647', '2021-08-17 15:56:31', NULL, NULL, '2021-08-17 00:00:00', 'ppppp', 1, '::1', NULL, 215, 1, 2, 0, 936520547, 12, NULL, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-17 15:56:31', NULL, NULL, 34, NULL),
	(168, 'aaa333', '2021-08-17 16:10:53', NULL, NULL, '0000-00-00 00:00:00', 'Pruebas', 1, '::1', NULL, 219, 1, 2, 0, 936520471, 12, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 3, NULL, '2021-08-17 16:10:53', NULL, 19, 0),
	(169, 'bgy910', '2021-08-18 08:28:33', NULL, NULL, '2021-08-12 00:00:00', 'Segunda prueba', 1, '::1', NULL, 215, 1, 1, 0, 789456, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:28:33', NULL, NULL, 35, NULL),
	(170, 'tgv145', '2021-08-18 08:32:10', NULL, NULL, '2021-08-19 00:00:00', 'Tercera prueba', 1, '::1', NULL, 215, 1, 2, 0, 147852369, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:32:10', NULL, NULL, 36, NULL),
	(171, 'mmm369', '2021-08-18 08:32:10', NULL, NULL, '2021-08-19 00:00:00', 'Tercera prueba', 1, '::1', NULL, 215, 1, 2, 0, 147852369, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:32:10', NULL, NULL, 37, NULL),
	(172, 'oll986', '2021-08-18 08:34:10', NULL, NULL, '2021-08-19 00:00:00', 'cuarta prueba', 1, '::1', NULL, 215, 2, 5, 0, 963147528, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:34:10', NULL, NULL, 38, NULL),
	(173, 'bbb444', '2021-08-18 08:44:00', NULL, NULL, '2021-08-19 00:00:00', 'Quinta prueba', 1, '::1', NULL, 215, 1, 3, 0, 852147, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:44:00', NULL, NULL, 39, NULL),
	(174, 'www919', '2021-08-18 08:44:00', NULL, NULL, '2021-08-19 00:00:00', 'Quinta prueba', 1, '::1', NULL, 215, 1, 3, 0, 852147, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:44:00', NULL, NULL, 40, NULL),
	(175, 'njp009', '2021-08-18 08:46:32', NULL, NULL, '2021-08-19 00:00:00', 'prueba 6', 1, '::1', NULL, 215, 1, 1, 0, 987654, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:46:32', NULL, NULL, 41, NULL),
	(176, 'qrp090', '2021-08-18 08:46:32', NULL, NULL, '2021-08-19 00:00:00', 'prueba 6', 1, '::1', NULL, 215, 1, 1, 0, 987654, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:46:32', NULL, NULL, 42, NULL),
	(177, 'aza999', '2021-08-18 08:48:54', NULL, NULL, '2021-08-19 00:00:00', 'prueba 7 ', 1, '::1', NULL, 215, 2, 2, 0, 4654981, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:48:55', NULL, NULL, 43, NULL),
	(178, 'pzq943', '2021-08-18 08:51:04', NULL, NULL, '2021-08-19 00:00:00', 'prueba 8 ', 1, '::1', NULL, 215, 1, 1, 0, 1213243534, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:51:04', NULL, NULL, 44, NULL),
	(179, 'lal645', '2021-08-18 08:53:14', NULL, NULL, '2021-08-20 00:00:00', 'prueba 9', 1, '::1', NULL, 215, 1, 2, 0, 1212, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:53:14', NULL, NULL, 45, NULL),
	(180, 'xxz990', '2021-08-18 08:55:15', NULL, NULL, '2021-08-19 00:00:00', 'prueba 10 ', 1, '::1', NULL, 215, 1, 2, 0, 654654, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:55:15', NULL, NULL, 46, NULL),
	(181, 'qpo110', '2021-08-18 08:55:15', NULL, NULL, '2021-08-19 00:00:00', 'prueba 10 ', 1, '::1', NULL, 215, 1, 2, 0, 654654, 12, NULL, 'Bogotá', 'Bogota', 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-18 08:55:15', NULL, NULL, 47, NULL),
	(182, 'AAE920', '2021-08-18 00:00:00', '2021-08-18 00:00:00', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 100', 1, '::1', 1, 217, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 Colombia', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-18 11:37:22', NULL, 1, 1),
	(183, 'AAE920', '2021-08-18 00:00:00', '2021-08-18 00:00:00', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 101', 1, '::1', 1, 217, 2, 3, 0, 938205580, 12, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-18 11:38:07', NULL, 1, 1),
	(184, 'AAE920', '2021-08-18 00:00:00', '2021-08-18 00:00:00', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 101', 1, '::1', 1, 217, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-18 12:01:48', NULL, 1, 1),
	(185, 'AAE920', '2021-08-18 00:00:00', '2021-08-18 00:00:00', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 101', 1, '::1', 1, 217, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-18 12:03:41', NULL, 1, 1),
	(186, 'AAE920', '2021-08-18 00:00:00', '2021-08-18 00:00:00', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 101', 1, '::1', 1, 217, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-18 12:05:50', NULL, 1, 1),
	(187, 'AAE920', '2021-08-18 12:08:17', '2021-08-18 12:08:17', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 101', 1, '::1', 1, 217, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-18 12:08:17', NULL, 1, 1),
	(188, 'AAE920', '2021-08-18 12:08:52', '2021-08-18 12:08:52', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 104 SAC', 1, '::1', 1, 217, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-18 12:08:52', NULL, 1, 1),
	(189, 'AAE920', '2021-08-18 12:23:34', '2021-08-18 12:23:34', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 105 SAC', 1, '::1', 1, 215, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-18 12:23:34', NULL, 1, 1),
	(190, 'AAE920', '2021-08-18 12:23:50', '2021-08-18 12:23:50', '2021-08-19 00:00:00', '2021-08-18 00:00:00', 'Esta es una observación de prueba 105 SAC', 1, '::1', 1, 215, 2, 3, 0, 938205580, 2, 0, 'Carrera 56 # 9 -09', 'Carrera 56 # 9 -09 ', 1, 1, 1, 0, 0, 0, 0, 0, 0, 'NULL', 0, '0000-00-00 00:00:00', 0, '2021-08-04 00:00:00', 1, 1, NULL, '2021-08-18 12:23:50', NULL, 1, 1),
	(191, 'AAE902', '2021-08-18 12:39:03', NULL, '2021-09-18 00:00:00', '0000-00-00 00:00:00', 'Purebas', 2, '::1', 1, 217, 1, 5, 1, 938202768, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 4, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-12 00:00:00', 0, '0000-00-00 00:00:00', 0, 2, NULL, '2021-08-18 12:39:03', NULL, 3, 1),
	(192, 'AAE902', '2021-08-18 12:39:03', NULL, '2021-07-18 00:00:00', '0000-00-00 00:00:00', 'Purebas', 2, '::1', 1, 217, 1, 5, 1, 938202768, 2, 0, 'Carrera 56 # 9 -09 Colombia', 'Carrera 56 # 9 -09 Colombia', 4, 2, 3, 0, 0, 0, 0, 0, 0, '', 0, '2021-08-12 00:00:00', 0, '0000-00-00 00:00:00', 0, 2, NULL, '2021-08-18 12:39:33', NULL, 3, 1),
	(193, 'QWM456', '2021-08-19 09:55:08', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-19 09:55:08', NULL, NULL, 52, NULL),
	(194, 'YHJ999', '2021-08-19 09:57:27', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-19 09:57:27', NULL, NULL, 53, NULL),
	(195, 'BBB836', '2021-08-19 09:57:27', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-19 09:57:27', NULL, NULL, 54, NULL),
	(196, 'ZXC789', '2021-08-19 09:57:27', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-19 09:57:27', NULL, NULL, 55, NULL),
	(197, 'LPJ901', '2021-08-19 10:20:49', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 999999, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-19 10:20:49', NULL, NULL, 56, NULL),
	(198, 'QWE851', '2021-08-19 11:22:58', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 56465, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-19 11:22:58', NULL, NULL, 57, NULL),
	(199, 'ZGT963', '2021-08-19 11:22:58', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 34657, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-19 11:22:58', NULL, NULL, 58, NULL),
	(200, 'MPZ109', '2021-08-19 11:22:58', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 3434, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-19 11:22:58', NULL, NULL, 59, NULL),
	(201, 'PPZ937', '2021-08-19 11:22:58', NULL, NULL, NULL, NULL, NULL, '::1', NULL, 215, 1, 1, NULL, 52464321, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '2021-08-19 11:22:59', NULL, NULL, 60, NULL);
/*!40000 ALTER TABLE `historico_gestiongopass` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.historico_persona
CREATE TABLE IF NOT EXISTS `historico_persona` (
  `historicoPersonaId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `celularLlamadas` int(11) DEFAULT NULL,
  `tipoId` int(11) NOT NULL,
  `celularWhatsapp` int(11) DEFAULT NULL,
  `cedulaPersona` int(11) NOT NULL,
  `fechaCreate` datetime NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `fechaUpdate` datetime DEFAULT NULL,
  `fechaDelete` datetime DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`historicoPersonaId`),
  KEY `cedulaPersona` (`cedulaPersona`),
  CONSTRAINT `historico_persona_ibfk_1` FOREIGN KEY (`cedulaPersona`) REFERENCES `persona` (`cedulaPersona`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.historico_persona: ~4 rows (aproximadamente)
DELETE FROM `historico_persona`;
/*!40000 ALTER TABLE `historico_persona` DISABLE KEYS */;
INSERT INTO `historico_persona` (`historicoPersonaId`, `nombre`, `apellido`, `telefono`, `celularLlamadas`, `tipoId`, `celularWhatsapp`, `cedulaPersona`, `fechaCreate`, `usuarioId`, `fechaUpdate`, `fechaDelete`, `ip`) VALUES
	(1, 'Pruebas', 'Cargue', 4528252, 2147483647, 1, 2147483647, 56465, '2021-08-19 11:22:58', 1, NULL, NULL, '::1'),
	(2, 'Pruebas', 'Cargue', 4528252, 2147483647, 1, 2147483647, 34657, '2021-08-19 11:22:58', 1, NULL, NULL, '::1'),
	(3, 'Pruebas', 'Cargue', 4528252, 2147483647, 1, 2147483647, 3434, '2021-08-19 11:22:58', 1, NULL, NULL, '::1'),
	(4, 'Pruebas', 'Cargue', 4528252, 2147483647, 1, 2147483647, 52464321, '2021-08-19 11:22:58', 1, NULL, NULL, '::1');
/*!40000 ALTER TABLE `historico_persona` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.historico_puntoactivacion
CREATE TABLE IF NOT EXISTS `historico_puntoactivacion` (
  `historicopuntoActivacionId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `ciudadId` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `fechaCambio` datetime NOT NULL,
  `puntoActivacionId` int(11) NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `fechaDelete` datetime DEFAULT NULL,
  PRIMARY KEY (`historicopuntoActivacionId`),
  KEY `usuarioId` (`usuarioId`),
  KEY `puntoActivacionId` (`puntoActivacionId`),
  CONSTRAINT `historico_puntoactivacion_ibfk_1` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`usuarioId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `historico_puntoactivacion_ibfk_2` FOREIGN KEY (`puntoActivacionId`) REFERENCES `puntoactivacion` (`puntoActivacionId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.historico_puntoactivacion: ~0 rows (aproximadamente)
DELETE FROM `historico_puntoactivacion`;
/*!40000 ALTER TABLE `historico_puntoactivacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `historico_puntoactivacion` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.historico_usuario
CREATE TABLE IF NOT EXISTS `historico_usuario` (
  `historicoId` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `cambioPassword` int(1) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `rolId` int(11) NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `fechaUpdate` datetime DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `usuarioModifico` int(11) DEFAULT NULL,
  PRIMARY KEY (`historicoId`),
  KEY `usuarioId` (`usuarioId`),
  CONSTRAINT `historico_usuario_ibfk_1` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`usuarioId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.historico_usuario: ~5 rows (aproximadamente)
DELETE FROM `historico_usuario`;
/*!40000 ALTER TABLE `historico_usuario` DISABLE KEYS */;
INSERT INTO `historico_usuario` (`historicoId`, `cedula`, `nombre`, `apellido`, `login`, `cambioPassword`, `estado`, `rolId`, `usuarioId`, `fechaUpdate`, `ip`, `usuarioModifico`) VALUES
	(146, 456123, 'PRUEBA4', 'Asesor', 'PRUEBA.ASESOR', 1, 1, 5, 12, '2021-08-19 13:03:53', '::1', 0),
	(147, 456123, 'PRUEBA4', 'Asesor', 'PRUEBA.ASESOR', 1, 1, 5, 12, '2021-08-19 13:04:46', '::1', 0),
	(148, 456123, 'PRUEBA4', 'Asesor', 'PRUEBA.ASESOR', 1, 1, 5, 12, '2021-08-19 13:07:07', '::1', 1),
	(149, 456123, 'PRUEBA4', 'Asesor', 'PRUEBA.ASESOR', 1, 1, 5, 12, '2021-08-19 13:08:06', '::1', 1),
	(152, 641321, 'PRUEBAS', 'Pruebas', 'prueba.master', 1, 1, 1, 26, '2021-08-19 13:39:54', '::1', 1);
/*!40000 ALTER TABLE `historico_usuario` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.localidad
CREATE TABLE IF NOT EXISTS `localidad` (
  `localidadId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ciudadId` int(11) NOT NULL,
  PRIMARY KEY (`localidadId`),
  KEY `ciudadId` (`ciudadId`),
  CONSTRAINT `localidad_ibfk_1` FOREIGN KEY (`ciudadId`) REFERENCES `ciudad` (`ciudadId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.localidad: ~5 rows (aproximadamente)
DELETE FROM `localidad`;
/*!40000 ALTER TABLE `localidad` DISABLE KEYS */;
INSERT INTO `localidad` (`localidadId`, `nombre`, `estado`, `ciudadId`) VALUES
	(1, 'LOCALIDAD 1', 1, 1),
	(2, 'LOCALIDAD 2', 1, 1),
	(3, 'LOCALIDAD 3', 1, 1),
	(4, 'LOCALIDAD 4', 1, 2),
	(5, 'LOCALIDAD 5', 1, 2);
/*!40000 ALTER TABLE `localidad` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.persona
CREATE TABLE IF NOT EXISTS `persona` (
  `cedulaPersona` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `celularLlamadas` int(11) DEFAULT NULL,
  `tipoId` int(11) NOT NULL,
  `celularWhatsapp` int(11) DEFAULT NULL,
  `usuarioId` int(11) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cedulaPersona`),
  KEY `tipoId` (`tipoId`),
  CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`tipoId`) REFERENCES `tipoidentificacion` (`tipoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.persona: ~57 rows (aproximadamente)
DELETE FROM `persona`;
/*!40000 ALTER TABLE `persona` DISABLE KEYS */;
INSERT INTO `persona` (`cedulaPersona`, `nombre`, `apellido`, `telefono`, `celularLlamadas`, `tipoId`, `celularWhatsapp`, `usuarioId`, `ip`) VALUES
	(1212, 'prueba 9', 'prueba 9', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(3434, 'Pruebas', 'Cargue', 4528252, 2147483647, 1, 2147483647, 1, '::1'),
	(34657, 'Pruebas', 'Cargue', 4528252, 2147483647, 1, 2147483647, 1, '::1'),
	(56465, 'Pruebas', 'Cargue', 4528252, 2147483647, 1, 2147483647, 1, '::1'),
	(654654, 'prueba 10', 'prueba 10', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(789456, 'pruebas 2 ', 'pruebas 2', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(852147, 'pruebas 5 ', 'pruebas 5', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(987654, 'prueba 6', 'prueba 6', 4652358, 2147483647, 1, 2147483647, NULL, NULL),
	(999999, 'Pruebas', 'Cargue', 4528252, 2147483647, 1, 2147483647, 1, '::1'),
	(4654981, 'prueba 7', 'prueba 7 ', 2147483647, 2147483647, 1, 2147483647, NULL, NULL),
	(14273142, 'Pruebas', 'Pruebas', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(52464321, 'Pruebas', 'Cargue', 4528252, 2147483647, 1, 2147483647, 1, '::1'),
	(147852369, 'pruebas 3', 'pruebas 3', 4528252, 2147483647, 2, 2147483647, NULL, NULL),
	(934111475, 'BERTA', 'GALOBART GARCIA', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(934500611, 'DAVID', 'BIDAULT PUEYO', 4652624, 2147483647, 1, 2147483647, NULL, NULL),
	(935687444, 'BERTA', 'LÓPEZ GARRIGASSAIT', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(935880712, 'LAURA', 'BIDAULT CULLERÉS', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(936012445, 'IVAN', 'LIBORI FIGUERAS', 4652358, 2147483647, 1, 2147483647, NULL, NULL),
	(936512105, 'MARIO', 'PASCUAL FLORES', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(936512545, 'RAMON', 'MORALES GESE', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(936520471, 'GEMMA', 'GARCIA ALMOGUERA', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(936520547, 'ESTHER', 'PASCUAL ALOY', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(936520741, 'GERARD', 'LÓPEZ DE PABLO GARCIA UCEDA', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(936524446, 'TONI', 'MAS FRANCH', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(936541235, 'SILVIA', 'RASERO GAVILAN', 4652358, 2147483647, 1, 2147483647, NULL, NULL),
	(936542775, 'DOUNYA', 'ZAFRA FIGULS', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(936545115, 'QUERALT', 'VISO GILABERT', 4652358, 2147483647, 1, 2147483647, NULL, NULL),
	(936565656, 'LAURA', 'VALLÉS GIRVENT', 4652358, 2147483647, 1, 2147483647, NULL, NULL),
	(936584541, 'MARIA', 'MOLINER GARRIDO', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(936658711, 'MIREIA', 'SÁNCHEZ GÓMEZ', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(936752156, 'RAQUEL', 'RAYA GARCIA', 4652624, 2147483647, 1, 2147483647, NULL, NULL),
	(936875255, 'JORDI', 'BIOSCA FONTANET', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(936875544, 'LLUÍS', 'ZAMBUDIO FIGULS', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(937785655, 'DAVID-JESE', 'BLANCO FONTANET', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(937809812, 'ADRIÀ', 'BERENGUERAS CULLERÉS', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(937885544, 'XAVIER', 'BENITEZ JOSE', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(938200022, 'ANDREU', 'BADIA TORNÉ', 4652624, 2147483647, 1, 2147483647, NULL, NULL),
	(938202200, 'JESUS', 'AYALA TORNÉ', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(938202456, 'ELIOT', 'ARNAU MORENO', 4652358, 2147483647, 1, 2147483647, NULL, NULL),
	(938202768, 'JOAN', 'AYALA FERRERAS', 4652624, 2147483647, 1, 2147483647, NULL, NULL),
	(938204054, 'ALBERT', 'ARNALOT PUIG', 4652624, 2147483647, 1, 2147483647, NULL, NULL),
	(938205580, 'ESTEFANIA', 'AROCAS PASADAS', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(938206097, 'JOAN MARTÍ', 'ASENSIO VEGA', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(938300025, 'JOAN', 'ANDREU CRUZ', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(938300385, 'ARAN', 'ALVAREZ FERNÁNDEZ', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(938305295, 'MARIA ISABEL', 'ALIGUÉ BONVEHÍ', 4652624, 2147483647, 1, 2147483647, NULL, NULL),
	(938305551, 'ALEJANDRO', 'ALOY COMPTE', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(938350521, 'MARC', 'BASTARDES SOTO', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(938385567, 'MARIA ISABEL', 'BARALDÉS COMAS', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(938727844, 'JOAN', 'BAEZ TEJADO', 4561236, 2147483647, 1, 2147483647, NULL, NULL),
	(938754554, 'JORDI', 'RAYA GAVILAN', 4652624, 2147483647, 1, 2147483647, NULL, NULL),
	(938755645, 'JOSEP', 'ANGUERA VILAFRANCA', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(938773545, 'JULIO', 'ALEU ICART', 4652358, 2147483647, 1, 2147483647, NULL, NULL),
	(938773941, 'GEMMA', 'ALAVEDRA SUNYÉ', 4652358, 2147483647, 1, 2147483647, NULL, NULL),
	(939965585, 'GEMMA', 'LISTAN FIGUERAS', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(963147528, 'pruebas 4 ', 'pruebas 4', 36987415, 2147483647, 1, 2147483647, NULL, NULL),
	(1016097645, 'Carlos', 'Bustos', 4528252, 2147483647, 1, 2147483647, NULL, NULL),
	(1213243534, 'prueba 8', 'prueba 8', 2147483647, 2147483647, 1, 2147483647, NULL, NULL);
/*!40000 ALTER TABLE `persona` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.puntoactivacion
CREATE TABLE IF NOT EXISTS `puntoactivacion` (
  `puntoActivacionId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `ciudadId` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `usuarioId` int(11) NOT NULL,
  PRIMARY KEY (`puntoActivacionId`),
  KEY `usuarioId` (`usuarioId`),
  KEY `ciudadId` (`ciudadId`),
  CONSTRAINT `puntoactivacion_ibfk_1` FOREIGN KEY (`usuarioId`) REFERENCES `usuario` (`usuarioId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `puntoactivacion_ibfk_2` FOREIGN KEY (`ciudadId`) REFERENCES `localidad` (`ciudadId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.puntoactivacion: ~9 rows (aproximadamente)
DELETE FROM `puntoactivacion`;
/*!40000 ALTER TABLE `puntoactivacion` DISABLE KEYS */;
INSERT INTO `puntoactivacion` (`puntoActivacionId`, `nombre`, `fechaCreacion`, `ciudadId`, `estado`, `ip`, `usuarioId`) VALUES
	(1, 'PUNTO 1', '2021-08-09 00:00:00', 2, 1, '', 4),
	(2, 'PUNTO 2', '2021-08-09 00:00:00', 2, 1, '', 4),
	(3, 'PUNTO 3', '2021-08-09 00:00:00', 2, 1, '', 4),
	(4, 'PUNTO 4', '2021-08-09 00:00:00', 2, 1, '', 4),
	(5, 'PUNTO 5', '2021-08-09 00:00:00', 2, 1, '', 4),
	(6, 'PUNTO 6', '2021-08-09 00:00:00', 2, 1, '', 4),
	(7, 'PUNTO 7', '2021-08-09 00:00:00', 2, 1, '', 4),
	(8, 'PUNTO 8', '2021-08-09 00:00:00', 2, 1, '', 4),
	(9, 'PUNTO 9', '2021-08-09 00:00:00', 2, 1, '', 4),
	(10, 'NO APLICA', '2021-08-09 00:00:00', 2, 1, '', 4);
/*!40000 ALTER TABLE `puntoactivacion` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.rol
CREATE TABLE IF NOT EXISTS `rol` (
  `rolId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`rolId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.rol: ~2 rows (aproximadamente)
DELETE FROM `rol`;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` (`rolId`, `nombre`, `fechaCreacion`, `estado`) VALUES
	(1, 'MASTER', '0000-00-00 00:00:00', 1),
	(3, 'COORDINADOR', '0000-00-00 00:00:00', 1),
	(4, 'SAC', '0000-00-00 00:00:00', 1),
	(5, 'ASESOR COMERCIAL', '0000-00-00 00:00:00', 1);
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.tipificacion
CREATE TABLE IF NOT EXISTS `tipificacion` (
  `tipificacionId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`tipificacionId`)
) ENGINE=InnoDB AUTO_INCREMENT=220 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.tipificacion: ~5 rows (aproximadamente)
DELETE FROM `tipificacion`;
/*!40000 ALTER TABLE `tipificacion` DISABLE KEYS */;
INSERT INTO `tipificacion` (`tipificacionId`, `nombre`, `fechaCreacion`, `estado`) VALUES
	(200, 'VENTA EFECTIVA', '2021-08-09 00:00:00', 1),
	(215, 'AGENDAMIENTO', '2021-08-09 00:00:00', 1),
	(216, 'NO CONTACTO\n', '2021-08-09 00:00:00', 1),
	(217, 'VOLVER A LLAMAR\n', '2021-08-09 00:00:00', 1),
	(218, 'REAGENDADO', '2021-08-09 00:00:00', 1),
	(219, 'DESISTE', '2021-08-09 00:00:00', 1);
/*!40000 ALTER TABLE `tipificacion` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.tipobono
CREATE TABLE IF NOT EXISTS `tipobono` (
  `tipoBonoId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`tipoBonoId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.tipobono: ~6 rows (aproximadamente)
DELETE FROM `tipobono`;
/*!40000 ALTER TABLE `tipobono` DISABLE KEYS */;
INSERT INTO `tipobono` (`tipoBonoId`, `nombre`, `estado`) VALUES
	(1, 'No aplica', 1),
	(2, 'BONO 1', 1),
	(3, 'BONO 2', 1),
	(4, 'BONO 3', 1),
	(5, 'BONO 4', 1),
	(6, 'BONO 5', 1),
	(7, 'BONO 6', 1);
/*!40000 ALTER TABLE `tipobono` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.tipoidentificacion
CREATE TABLE IF NOT EXISTS `tipoidentificacion` (
  `tipoId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  PRIMARY KEY (`tipoId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.tipoidentificacion: ~2 rows (aproximadamente)
DELETE FROM `tipoidentificacion`;
/*!40000 ALTER TABLE `tipoidentificacion` DISABLE KEYS */;
INSERT INTO `tipoidentificacion` (`tipoId`, `nombre`) VALUES
	(1, 'CC'),
	(2, 'CE'),
	(3, 'NO APLICA');
/*!40000 ALTER TABLE `tipoidentificacion` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.tipomembresia
CREATE TABLE IF NOT EXISTS `tipomembresia` (
  `tipoMembresiaId` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `estado` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`tipoMembresiaId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.tipomembresia: ~7 rows (aproximadamente)
DELETE FROM `tipomembresia`;
/*!40000 ALTER TABLE `tipomembresia` DISABLE KEYS */;
INSERT INTO `tipomembresia` (`tipoMembresiaId`, `nombre`, `estado`) VALUES
	(1, 'No aplica', 1),
	(2, 'Membresía 1', 1),
	(3, 'Membresía 2', 1),
	(4, 'Membresía 3', 1),
	(5, 'Membresía 4', 1),
	(6, 'Membresía 5', 1),
	(7, 'Membresía 6', 1);
/*!40000 ALTER TABLE `tipomembresia` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `usuarioId` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellido` varchar(45) NOT NULL,
  `login` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `rolId` int(11) NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `dateAction` datetime DEFAULT NULL,
  `usuarioModifico` int(11) DEFAULT NULL,
  `cambioPassword` int(1) DEFAULT NULL,
  PRIMARY KEY (`usuarioId`),
  KEY `rolId` (`rolId`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`rolId`) REFERENCES `rol` (`rolId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.usuario: ~5 rows (aproximadamente)
DELETE FROM `usuario`;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`usuarioId`, `cedula`, `nombre`, `apellido`, `login`, `password`, `estado`, `rolId`, `ip`, `dateAction`, `usuarioModifico`, `cambioPassword`) VALUES
	(1, 123456, 'ALEXANDER', 'MENDEZ', 'elalexmendez', '123456', 1, 3, '::1', '2021-08-19 13:39:54', NULL, 0),
	(2, 789456, 'Asesor SAC', 'Sac', 'sac', '123456', 1, 4, '::1', '2021-08-18 12:46:07', 4, 1),
	(4, 555555, 'MASTER', 'MASTER', 'MASTER', '123456', 1, 1, '::1', NULL, NULL, NULL),
	(12, 456123, 'PRUEBA4', 'Asesor', 'PRUEBA.ASESOR', '7c4a8d09ca3762af61e59520943dc26494f8941b', 1, 5, '::1', '2021-08-18 11:59:50', 4, 1),
	(26, 641321, 'PRUEBAS', 'Pruebas', 'prueba.master', '7c4a8d09ca3762af61e59520943dc26494f8941b', 1, 1, '::1', NULL, NULL, NULL);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

-- Volcando estructura para tabla gestiongopass.ventatag
CREATE TABLE IF NOT EXISTS `ventatag` (
  `tagAsociado` int(11) NOT NULL,
  PRIMARY KEY (`tagAsociado`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla gestiongopass.ventatag: ~2 rows (aproximadamente)
DELETE FROM `ventatag`;
/*!40000 ALTER TABLE `ventatag` DISABLE KEYS */;
INSERT INTO `ventatag` (`tagAsociado`) VALUES
	(0),
	(123456);
/*!40000 ALTER TABLE `ventatag` ENABLE KEYS */;

-- Volcando estructura para disparador gestiongopass.convenio_AFTER_DELETE
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `gestiongopass`.`convenio_AFTER_DELETE` AFTER DELETE ON `convenio` FOR EACH ROW
BEGIN
insert into historico_convenio(nombre, fechaDelete, estado, convenioId, usuarioId, ip, fechaUpdate, fechaInsert)
values(old.nombre, now(), old.estado, old.convenioId, old.usuarioId, old.ip, null, null);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador gestiongopass.convenio_AFTER_INSERT
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `gestiongopass`.`convenio_AFTER_INSERT` AFTER INSERT ON `convenio` FOR EACH ROW
BEGIN
insert into historico_convenio(nombre, fechaInsert, estado, convenioId, usuarioId, ip, fechaUpdate, fechaDelete)
values(new.nombre, now(), new.estado, new.convenioId, new.usuarioId, new.ip, null, null);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador gestiongopass.convenio_AFTER_UPDATE
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `gestiongopass`.`convenio_AFTER_UPDATE` AFTER UPDATE ON `convenio` FOR EACH ROW
BEGIN
insert into historico_convenio(nombre, fechaUpdate, estado, convenioId, usuarioId, ip, fechaDelete, fechaInsert)
values(new.nombre, now(), new.estado, new.convenioId, new.usuarioId, new.ip, null, null);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador gestiongopass.gestiongopass_AFTER_INSERT
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `gestiongopass`.`gestiongopass_AFTER_INSERT` AFTER INSERT ON `gestiongopass` FOR EACH ROW
BEGIN
insert into historico_gestiongopass(placa, fechaGestion, fechaReagendamiento, fechaVolverLlamar, fechaEntrega, observacion, 
	numTags, ip, conoceMembresias, tipificacionId, convenioId, barrioId, franjaHoraria, cedulaPersona, usuarioId, presentacionPersonal, 
	direccionCasa, direccionEntrega, tipoBonoId, tipoMembresiaId, campanaId, calificacionPresentacionPersonal, calificacionInfoClara, 
	calificacionAcompanamiento, calificacionTiempoEspera, calificacionComportamiento, calificacionAmabilidad, motivoNoContacto, 
	tagAsociado, fechaActivacion, redimeBono, fechaRedimeBono, adquiereMembresia, puntoActivacionId, fechaCreacion, fechaUpdate, 
	fechaDelete, gestionId, existeContacto)
	values(new.placa, new.fechaGestion, new.fechaReagendamiento, new.fechaVolverLlamar, new.fechaEntrega, new.observacion, 
	new.numTags, new.ip, new.conoceMembresias, new.tipificacionId, new.convenioId, new.barrioId, new.franjaHoraria, new.cedulaPersona, new.usuarioId, 
	new.presentacionPersonal, new.direccionCasa, new.direccionEntrega, new.tipoBonoId, new.tipoMembresiaId, new.campanaId, 
	new.calificacionPresentacionPersonal, new.calificacionInfoClara, new.calificacionAcompanamiento, new.calificacionTiempoEspera, 
	new.calificacionComportamiento, new.calificacionAmabilidad, new.motivoNoContacto, new.tagAsociado, new.fechaActivacion, 
	new.redimeBono, new.fechaRedimeBono, new.adquiereMembresia, new.puntoActivacionId, now(), null, null, new.gestionId, new.existeContacto);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador gestiongopass.gestiongopass_AFTER_UPDATE
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `gestiongopass`.`gestiongopass_AFTER_UPDATE` AFTER UPDATE ON `gestiongopass` FOR EACH ROW
BEGIN
insert into historico_gestiongopass(placa, fechaGestion, fechaReagendamiento, fechaVolverLlamar, fechaEntrega, observacion, 
	numTags, ip, conoceMembresias, tipificacionId, convenioId, barrioId, franjaHoraria, cedulaPersona, usuarioId, presentacionPersonal, 
	direccionCasa, direccionEntrega, tipoBonoId, tipoMembresiaId, campanaId, calificacionPresentacionPersonal, calificacionInfoClara, 
	calificacionAcompanamiento, calificacionTiempoEspera, calificacionComportamiento, calificacionAmabilidad, motivoNoContacto, 
	tagAsociado, fechaActivacion, redimeBono, fechaRedimeBono, adquiereMembresia, puntoActivacionId, fechaCreacion, fechaUpdate, 
	fechaDelete, gestionId, existeContacto)
	values(new.placa, new.fechaGestion, new.fechaReagendamiento, new.fechaVolverLlamar, new.fechaEntrega, new.observacion, 
	new.numTags, new.ip, new.conoceMembresias, new.tipificacionId, new.convenioId, new.barrioId, new.franjaHoraria, new.cedulaPersona, new.usuarioId, 
	new.presentacionPersonal, new.direccionCasa, new.direccionEntrega, new.tipoBonoId, new.tipoMembresiaId, new.campanaId, 
	new.calificacionPresentacionPersonal, new.calificacionInfoClara, new.calificacionAcompanamiento, new.calificacionTiempoEspera, 
	new.calificacionComportamiento, new.calificacionAmabilidad, new.motivoNoContacto, new.tagAsociado, new.fechaActivacion, 
	new.redimeBono, new.fechaRedimeBono, new.adquiereMembresia, new.puntoActivacionId, null, now(), null, new.gestionId, new.existeContacto);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador gestiongopass.persona_AFTER_DELETE
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `gestiongopass`.`persona_AFTER_DELETE` AFTER DELETE ON `persona` FOR EACH ROW
BEGIN
insert into historico_persona(nombre, apellido, telefono, celularLlamadas, tipoId, celularWhatsapp, cedulaPersona, fechaDelete, usuarioId, ip)
values(old.nombre, old.apellido, old.telefono, old.celularLlamadas, old.tipoId, old.celularWhatsapp, old.cedulaPersona, now(), old.usuarioId, old.ip);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador gestiongopass.persona_AFTER_INSERT
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `gestiongopass`.`persona_AFTER_INSERT` AFTER INSERT ON `persona` FOR EACH ROW
BEGIN
insert into historico_persona(nombre, apellido, telefono, celularLlamadas, tipoId, celularWhatsapp, cedulaPersona, fechaCreate, usuarioId, ip)
values(new.nombre, new.apellido, new.telefono, new.celularLlamadas, new.tipoId, new.celularWhatsapp, new.cedulaPersona, now(), new.usuarioId, new.ip);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Volcando estructura para disparador gestiongopass.persona_AFTER_UPDATE
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `gestiongopass`.`persona_AFTER_UPDATE` AFTER UPDATE ON `persona` FOR EACH ROW
BEGIN
insert into historico_persona(nombre, apellido, telefono, celularLlamadas, tipoId, celularWhatsapp, cedulaPersona, fechaUpdate, usuarioId, ip)
values(new.nombre, new.apellido, new.telefono, new.celularLlamadas, new.tipoId, new.celularWhatsapp, new.cedulaPersona, now(), new.usuarioId, new.ip);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
